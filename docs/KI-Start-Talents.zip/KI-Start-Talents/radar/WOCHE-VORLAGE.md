# Radar Woche

**Woche vom:** ______

## Drei Videos

1. Titel und Kanal: ______
   Was drin war, ein Satz: ______
2. Titel und Kanal: ______
   Was drin war, ein Satz: ______
3. Titel und Kanal: ______
   Was drin war, ein Satz: ______

## Eine GitHub-Liste oder ein Repo

Name und Link: ______
Warum mir das aufgefallen ist, ein Satz: ______

## Entscheidung

Der eine Hebel, den ich diese Woche ausprobiere: ______
Was dabei rauskam: ______
