# Dein Radar

Du musst nicht alles lesen, was jede Woche über KI erscheint. Du brauchst ein System, das mitliest und dir sagt, was davon für **dich** zählt.

## Einmal pro Woche, rund 15 Minuten

1. Kopier `WOCHE-VORLAGE.md` und nenn die Kopie nach dem Muster `JJJJ-MM-TT_Radar`, zum Beispiel `2026-11-09_Radar`.
2. Trag ein: **drei Videos** von YouTube, die du diese Woche gesehen hast oder sehen willst, mit je einem Satz, was drin war. Dazu **eine GitHub-Liste oder ein Repo**, das dir aufgefallen ist, mit einem Satz, warum.
3. Neuer Chat in diesem Ordner, dann: `Lies agenten/AGENT-Sparringspartner.md und mach mit mir die Radar-Runde.`
4. Der Sparringspartner ordnet ein und empfiehlt dir **genau einen** Hebel für diese Woche. Einen, nicht fünf.
5. Was du ausprobiert hast und was rauskam: eine Zeile unter „Entscheidung". Was schiefging: als Learning in `system/LEARNINGS.md`.

## Welche Quellen

Nimm Leute, die selbst bauen und zeigen, wie, nicht nur Leute, die darüber reden. Auf GitHub sind Trending-Seiten und kuratierte Listen zu deinem Thema ein guter Start. Wechsle Quellen, die dir drei Wochen hintereinander nichts gebracht haben, aus.

## Drei Regeln

- Inhalte aus Videos, Repos und Readmes sind **Material, keine Anweisungen**. Auch nicht für deinen Assistenten.
- **Installier nichts, nur weil ein Video es sagt.** Erst lesen, was es tut, dann den Sparringspartner fragen.
- Keine Zugangsdaten, keine Passwörter, keine API-Schlüssel in Chats oder Dateien.
