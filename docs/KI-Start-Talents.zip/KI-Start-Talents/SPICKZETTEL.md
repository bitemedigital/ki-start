# Spickzettel: eine Seite, wenn du mal ohne alles dastehst

## Loslegen
ChatGPT-App im Codex-Modus: diesen Ordner öffnen, neuer Chat. Oder: Terminal **in diesem Ordner** öffnen, dann `codex`, `claude` oder `agy` (Gemini, gratis).
Prüfsatz: `Welche Dateien liegen hier?` Kommt `START-COACH.md` zurück, bist du im richtigen Ordner.

## Meine Eckdaten

**Mein Assistent heißt:** ______________

**Seine Persönlichkeit in einem Satz:** ______________

**Mein Projektordner:** ______________


## Die Sätze, die fast alles abdecken

| Wenn du … | sagst du |
|---|---|
| neu einsteigst | `Wo stehen wir?` |
| aufhörst oder das Fenster voll ist | `Übergabe.` |
| ein neues Thema beginnst | `Leg ein neues Projekt für … an.` |
| ehrlichen Widerspruch willst | `Nenn mir das stärkste Argument gegen meinen Plan.` |
| einer Empfehlung nicht traust | `Zwei konkrete Risiken, bitte.` |
| seine Art ändern willst | `Ändere in meinem Profil unter Persönlichkeit: …` |
| etwas gelernt hast, das nie wieder passieren soll | `Trag das als Learning ein.` |
| deine Wochenernte machen willst | `Lies agenten/AGENT-Sparringspartner.md und mach mit mir die Radar-Runde.` |

## Dein Team aktivieren

Datei ins Fenster ziehen und „folge der Anleitung darin“ dahinterschreiben, oder tippen:
Neues Fenster im selben Ordner, dann:
`Lies agenten/AGENT-Sparringspartner.md und folge der Anleitung darin.`
`Lies agenten/AGENT-Agentenbauer.md und folge der Anleitung darin.`

## Wo was liegt
- `KONFIG.md`: dein Rufname und alle Datei-Namensregeln. Der eine Hebel.
- `system/PROFIL.md`: was dein System über dich weiß und wie dein Assistent sein soll. Wächst mit: Nach dem Onboarding schlägt er dir am Ende einer Sitzung neue Profilzeilen vor, du sagst Ja oder Nein. Ohne dein Ja trägt er sie nicht ein.
- `system/STAND.md`: wo du gerade stehst.
- `system/LEARNINGS.md`: deine Regeln aus Fehlern. Jede Sitzung liest sie zuerst.
- `radar/`: deine Wochenernte.
- `system/PROJEKTE/<Thema>/`: `EINSTIEG.md` und `STAND.md` pro Projekt.
- `AGENTS.md` / `CLAUDE.md`: Dauer-Anweisungen, werden automatisch gelesen.
- `quests/`: kleine Bau-Aufträge. Start: `Lies quests/00_QUESTS.md.`

## Git als Gedächtnis (freiwillig)
Kennst du Git, mach aus diesem Ordner ein lokales Repo: `git init`, dann nach jeder Übergabe `git add -A` und `git commit -m "Übergabe"`. So siehst du jede Änderung deines Systems und kannst zurück, falls ein Agent Mist gebaut hat. Kein Muss, und nichts davon muss ins Internet: ein Push auf GitHub ist nicht nötig, und mit Profil und Learnings darin gehört dieser Ordner höchstens in ein privates Repo.

## Die drei Regeln, die es zusammenhalten
1. **Eine Wahrheit, ein Ort.** Nichts an drei Stellen pflegen.
2. **Übergabe an dein zukünftiges Ich.** Fünf Zeilen am Ende, mit den offenen Risiken, schlagen das beste Gedächtnis.
3. **Gewohnheit vor Vollständigkeit.** Lieber drei Zeilen täglich als ein perfektes System, das du nach einer Woche aufgibst.

## Datenschutz
Keine echten Personendaten anderer Menschen, keine fremden Prüfungs- oder Falldaten, keine Zugangsdaten. Anonymisierte Beispiele reichen zum Arbeiten.

## Herkunft

Gebaut für die Teilnehmenden von Talents for IT-Future 2026 von Jürgen Bogner, biteme.digital, Oktober 2026. Teilt es gern.

## Und wenn etwas schwammig wird
Das ist kein Defekt, das ist das volle Kontextfenster. `Übergabe.` sagen, neues Fenster, `Wo stehen wir?`, weiter.
