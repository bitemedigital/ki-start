# KONFIG: dein KI-System

> Fassung für die **Teilnehmenden von Talents for IT-Future 2026**. Gebaut von Jürgen Bogner, biteme.digital, Oktober 2026. Teilt es gern, baut es weiter aus.
>
> **Paket-Kennung:** `KI-Start-Talents · Master v3.2 · 01.11.2026`

> Diese Datei ist der **eine Steuerungs-Hebel** des Systems. Der Coach und alle Agenten lesen sie zuerst und richten sich danach. Du kannst sie jederzeit ändern, alles andere zieht nach.

## Mein Profil (Kurzfassung)

- **Name:** [der Coach fragt beim ersten Start nach deinem Namen und trägt ihn hier ein]
- **Was ich mache:** [trägt der Coach in Akt 1 ein]
- **Womit ich arbeite:** [Codex / Claude Code / Gemini in Antigravity, trägt der Coach ein]
- **Mein Ziel mit diesem System:** [trägt der Coach ein]
- **Erfahrung mit KI:** [Anfänger / Fortgeschritten / Profi]

> Die ausführliche, wachsende Fassung liegt in `system/PROFIL.md`. Diese hier ist nur die Kurzform zum schnellen Nachschlagen.

## NAMENS-SET: die Ablage-Konvention dieses Systems

> Damit jede frische KI-Instanz zuverlässig weiß, wo was liegt. Der Coach und alle Agenten benutzen **genau diese Namen** und lesen sie **von hier**, nicht aus dem Gedächtnis.

### Die Ablage-Namen

Gefahrlos ändern kannst du nur `rufname` und `dateinamen`. Die Pfade bleiben, wie sie sind: Coach und Dauer-Anweisungen kennen sie beim Namen.

| Rolle | Wert | Wofür |
|---|---|---|
| `rufname` | `[DEIN-ASSISTENT]` | Der Name deines Assistenten. Den vergibst du beim Coach, in Akt 1 oder im Bau-Weg. |
| `profil` | `system/PROFIL.md` | Was das System über dich weiß. Wächst mit. |
| `projekte` | `system/PROJEKTE/` | Ein Unterordner pro Thema. `_VORLAGE/` darin ist das Kopiergerüst, kein Projekt. |
| `einstieg` | `EINSTIEG.md` | Pro Projekt: worum geht es, wie steigt man ein. |
| `stand-projekt` | `STAND.md` | Pro Projekt: aktueller Stand und Übergaben, neueste zuerst. |
| `archiv` | `system/ARCHIV/` | Überholte Versionen. **Nie löschen, immer verschieben.** |
| `learnings` | `system/LEARNINGS.md` | Was nie wieder passieren soll: ein Fehler wird eine Regel, mit Datum. |
| `radar` | `radar/` | Deine Wochenernte aus YouTube und GitHub. |
| `agenten` | `agenten/AGENT-<Name>.md` | Deine Spezialisten. |
| `dateinamen` | `JJJJ-MM-TT_Thema` | z.B. `2026-09-01_Seminararbeit-Gliederung` |

### Fest vorgegeben: nicht umbenennen

Diese vier Namen kommen nicht von uns, sondern vom Werkzeug beziehungsweise von der Boot-Logik. Wer sie ändert, schaltet das automatische Laden ab, und keine frische Sitzung findet mehr den Einstieg.

| Name | Wofür |
|---|---|
| `AGENTS.md` | Dauer-Anweisungen. **Codex und Antigravity (Gemini) lesen sie automatisch.** |
| `CLAUDE.md` | Dasselbe für Claude Code. |
| `system/STAND.md` | Der eine Ort, an dem steht, wo du gerade bist. Jede Sitzung liest ihn zuerst. |
| `START-COACH.md` | Dein Onboarding-Coach. Die Boot-Logik ruft ihn beim Namen. |

**Regel für jede KI, die in diesem Ordner arbeitet:** Bevor du eine Datei anlegst oder suchst, liest du diese Tabellen und benutzt die Werte, die hier stehen. Steht hier ein anderer Wert als in deiner Erinnerung, gilt der hier.

**Willst du deinem Assistenten einen anderen Namen geben?** Ändere `rufname` oben und sag ihm einmal: `Lies KONFIG.md neu.` Die Pfade lässt du so, sonst findet eine neue Sitzung ihre Dateien nicht.

## Warum diese Namen

`AGENTS.md` und `CLAUDE.md` sind die zwei Dateien, die Codex und Antigravity beziehungsweise Claude Code **von selbst lesen**, wenn du sie in diesem Ordner startest. Dein Assistent kennt seine Dauer-Anweisungen also in jeder neuen Sitzung, ohne dass du etwas tust. Beide liegen hier und haben denselben Inhalt, damit das System in beiden Werkzeugen identisch läuft.

`EINSTIEG`, `STAND` und `ARCHIV` sind bewusst klare deutsche Wörter, damit du auf einen Blick weißt, was was ist.
