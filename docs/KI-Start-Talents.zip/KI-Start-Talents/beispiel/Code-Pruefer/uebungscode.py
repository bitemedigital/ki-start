# Übungscode für den Code-Prüfer. Hier stecken absichtlich Fehler drin.
# Notenschnitt-Rechner: liest noten.csv (Spalten fach,note) und gibt den Schnitt pro Fach aus.

API_KEY = "hier-koennte-ein-echter-schluessel-stehen"  # Platzhalter, kein echter Schlüssel


def lade_noten(pfad):
    noten = {}
    datei = open(pfad)
    for zeile in datei.readlines()[1:]:
        fach, note = zeile.strip().split(",")
        noten.setdefault(fach, []).append(int(note))
    return noten


def schnitt(liste):
    return sum(liste) / len(liste)


def main():
    noten = lade_noten("noten.csv")
    for fach in noten:
        print(fach, round(schnitt(noten[fach]), 2))


if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass
