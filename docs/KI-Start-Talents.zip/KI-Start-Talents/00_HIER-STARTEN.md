# Hier starten

> **Für die KI, die diese Datei liest:** Wurdest du gebeten, dieser Anleitung zu folgen, dann lies jetzt `START-COACH.md` und folge der Anleitung darin. Fass diese Datei nicht zusammen, starte den Coach.

> **Dein KI-Startsystem aus der Keynote „Nicht besser tippen. Besser denken."** bei Talents for IT-Future am 04.11.2026. Gebaut von Jürgen Bogner und biteme.digital.
>
> Das gehört jetzt dir. Teilt es gern, baut es weiter aus, macht es besser.

Das hier ist kein Chatbot. Es ist ein kleines Arbeitssystem: echte Dateien auf deinem Rechner, ein Assistent, der sich über einzelne Chats hinweg erinnert, und drei KI-Kollegen.

| Kollege | Was er macht |
|---|---|
| **Coach** (Onboarder) | Richtet alles mit dir ein. Er startet als Erstes und führt dich Schritt für Schritt. |
| **Sparringspartner** | Prüft deine Ideen ehrlich und widerspricht dir, statt dir nach dem Mund zu reden. |
| **Agentenbauer** | Hilft dir, weitere Kollegen zu bauen, und lässt sie im anderen Modell gegenprüfen. |

Unterwegs lernst du fünf Dinge, die du danach jeden Tag brauchst: deinem Assistenten einen **Namen** und eine **Persönlichkeit** geben, dein Wissen **im Ordner** aufbauen statt in Chats zu verlieren, die **Übergabe** von einem Chat zum nächsten, **Learnings** (ein Fehler wird eine Regel) und **sparren** statt abfragen. Es geht in Etappen. Sag jederzeit „Pause", dann geht es beim nächsten Mal genau dort weiter.

## Was du brauchst

- Ein **eigenes Konto** bei OpenAI (ChatGPT), Anthropic (Claude) oder Google (Gemini), nicht mit anderen geteilt.
- **Alter, ehrlich:** Claude ist laut den Nutzungsbedingungen von Anthropic erst ab 18. ChatGPT darfst du unter 18 nur mit Zustimmung deiner Eltern nutzen. Google erlaubt Gemini auch Jugendlichen mit eigenem Google-Konto. Bist du jünger oder hast gerade kein passendes Konto, nimm den Gemini-Weg unten oder `GRATIS-FASSUNG.md`, die läuft in jedem normalen Chat.
- **Welcher Tarif:** Codex ist laut OpenAI (Stand Herbst 2026) in allen ChatGPT-Plänen enthalten, auch im kostenlosen; wie viel du damit arbeiten kannst, hängt vom Plan ab. Claude Code braucht einen bezahlten Claude-Plan. **Gemini über Google Antigravity** ist mit einem normalen Google-Konto gratis, mit einem Kontingent, das sich jede Woche erneuert (Google nennt keine feste Zahl). Pläne und Preise ändern sich, schau im Zweifel beim Anbieter nach.
- Einen **Mac oder Windows-Rechner**, auf dem du Programme installieren darfst. Auf Schulrechnern ist das oft gesperrt, dann nimm deinen eigenen.
- **Datenschutz:** Die Dateien liegen auf deinem Rechner, aber was die KI liest, verarbeitet der Anbieter (OpenAI, Anthropic oder Google). Bei Gratis-Konten lohnt ein Blick in die Einstellungen, ob deine Chats zum Training genutzt werden. Schreib nichts hinein, was du nicht auch einem Fremden erzählen würdest, und nichts über andere Menschen.
- Leg diesen Ordner an einen **festen Platz**, zum Beispiel in *Dokumente*, nicht in *Downloads*.

## Schritt 0: einmal einrichten

Vier Wege, nimm einen. Die Karten erklären jeden Schritt.

| Weg | Für wen | Karte |
|---|---|---|
| **Codex im Terminal** | Du kennst das Terminal ein bisschen. Unser getesteter Weg. | `plattform/KARTE-Codex.md` |
| **ChatGPT-App, Codex-Modus** | Ohne Terminal, alles mit der Maus. | `plattform/KARTE-ChatGPT-App-Mac.md` oder `plattform/KARTE-ChatGPT-App-Windows.md` |
| **Claude Code im Terminal** | Du hast ein Claude-Abo und bist 18. Am einfachsten auf dem Mac. | `plattform/KARTE-Claude-Code.md` |
| **Gemini in Google Antigravity** | Gratis mit Google-Konto, auch unter 18. App oder Terminal. | `plattform/KARTE-Gemini-Antigravity.md` |

**Ehrlich zum App-Weg:** Die Karten für die ChatGPT-App sind gegen die offizielle Hilfe von OpenAI geschrieben, aber noch nicht in jedem Klick von uns selbst durchprobiert. Stellen mit „(beim ersten Lauf prüfen)" sind genau solche. Für Antigravity haben wir den Terminal-Weg (`agy`) am Mac getestet, die Desktop-App noch nicht in jedem Klick. Hakt etwas, nimm den Terminal-Weg, der ist getestet.

**Zwei Dinge für die ChatGPT-App, auf Windows getestet:**
- Windows legt beim Entpacken oft einen Ordner im Ordner an. Öffne den **inneren**, in dem diese Datei direkt liegt.
- Die App fragt beim Speichern immer wieder, ob sie Dateien bearbeiten darf. **Klick jedes Mal „Einmal zulassen".**

## So legst du los

1. Öffne einen neuen Chat **in genau diesem Ordner** (wie, steht in deiner Karte).
2. Schreib: `Lies 00_HIER-STARTEN.md und folge der Anleitung.`
3. Der Coach übernimmt ab hier. Er fragt dich als Erstes, welchen Weg du willst: die **geführte Tour** (rund 40 Minuten) oder den **Bau-Weg**, bei dem du nach zwei Fragen direkt eine Quest baust.

Du musst Dateinamen nicht abtippen: Zieh eine Datei aus dem Finder oder Explorer ins Chatfenster und schreib dahinter „folge der Anleitung darin".

**Prüfsatz, wenn du unsicher bist:** `Welche Dateien liegen hier?` Kommen `START-COACH.md` und `KONFIG.md` zurück, bist du im richtigen Ordner.

## Was am Ende da ist

- Ein Assistent mit Namen und Persönlichkeit, die **du** festlegst, und einem Gedächtnis, das mit dir wächst.
- Ein Profil von dir, aus dem heraus dein Sparringspartner dich kennt.
- Dein erstes echtes Projekt, sauber abgelegt.
- Die **Übergabe** und deine ersten **Learnings**, einmal selbst erlebt.
- Ein Team: Sparringspartner und Agentenbauer.
- Ein **Radar** für deine Wochenernte aus YouTube und GitHub.

## Was wo liegt

- `START-COACH.md`: dein Coach. Damit fängt alles an.
- `KONFIG.md`: Rufname und Ablage-Regeln. Der eine Hebel.
- `AGENTS.md` und `CLAUDE.md`: die Dauer-Anweisungen. Codex und Antigravity lesen `AGENTS.md` automatisch, Claude Code liest `CLAUDE.md`. Beide haben denselben Inhalt.
- `system/`: dein Gedächtnis mit Profil, Stand, Learnings, Projekten und Archiv.
- `agenten/`: dein Team.
- `quests/`: kleine Bau-Aufträge mit echtem Ergebnis.
- `beispiel/`: ein fertiger Beispiel-Agent zum Abschauen.
- `radar/`: deine Wochenernte.
- `plattform/`: die Karten zum Einrichten.
- `GRATIS-FASSUNG.md`: das Ganze als Prompts für jeden normalen Chat.
- `SPICKZETTEL.md`: eine Seite zum Ausdrucken.

## Wenn du hängst

Frag deinen Assistenten: `Ich hänge bei … Was ist der kleinste nächste Schritt?` Und wenn du uns etwas sagen willst, was gut lief oder was fehlt: juergen@biteme.digital.

*Gebaut von biteme.digital*
