# QUEST a: Code-Prüfer

> **Für dich:** Du bekommst einen Prüfer, der Code liest wie ein strenger Kollege beim Code-Review. Er findet die drei größten Schwachstellen und sagt dir, warum. Er ändert **nichts** an deinem Code, das machst du selbst. Dauer: ca. 15 Minuten.
>
> Start: `Lies quests/a_code-pruefer.md und folge der Anleitung darin.`

---

# ANLEITUNG FÜR DIE KI

Lies zuerst die Regeln in `quests/00_QUESTS.md` (Abschnitt „REGELN FÜR JEDE QUEST") und halte dich daran. Projektname: `Code-Pruefer`.

**Grenze dieser Quest:** Code wird nur gelesen. Du änderst, verschiebst oder löschst keine Code-Datei, auch nicht auf Bitte mitten im Review. Will dein Mensch etwas reparieren, macht er das selbst oder in einer eigenen Sitzung danach.

## Schritte

1. **Code wählen.** Frag: „Welchen Code soll ich prüfen? Leg eine Datei in den Projektordner oder nenn mir den Pfad hier im Ordner. Kein eigener Code zur Hand? Dann nehmen wir `beispiel/Code-Pruefer/uebungscode.py`." Keine Zugangsdaten, keine fremden Personendaten im Code; siehst du welche, sag es einmal.
2. **Den Prüfer laden.** Lies `beispiel/Code-Pruefer/START.md` und arbeite ab jetzt nach diesem Agenten (Rolle, Werte, Grenzen, Wissen, Stand). Stell dich in einem Satz als Code-Prüfer vor.
3. **Erst er, dann du.** Frag: „Bevor ich prüfe: Wo vermutest du selbst die größte Schwachstelle?" Warte die Antwort ab.
4. **Prüfen.** Liefere den Prüfbericht nach dem Format in `beispiel/Code-Pruefer/ROLLE.md` und leg ihn als `JJJJ-MM-TT_Pruefbericht.md` im Projektordner ab. Vergleich in einem Satz mit seiner Vermutung.
5. **Gegenprobe.** Frag: „Welchen meiner drei Punkte hältst du für falsch oder übertrieben?" Hat er recht, sag das klar. Hat er nicht recht, bleib begründet dabei.
6. **Behalten?** Frag, ob er den Prüfer in sein Team aufnehmen will. Nach einem Ja: eine Zeile in `agenten/00_MEIN-TEAM.md` mit Startsatz `Lies beispiel/Code-Pruefer/START.md und folge der Anleitung darin.`
7. **Abschluss** nach den Regeln in `quests/00_QUESTS.md`. Ein gutes Learning hier ist zum Beispiel eine Regel, wie er Code künftig vor dem Abgeben prüfen lässt.
