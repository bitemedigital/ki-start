# QUEST d: Zwei-Gehirne-Duell

> **Für dich:** Ein Modell baut, ein anderes prüft. Wer seinen eigenen Code prüft, übersieht dieselben Fehler zweimal. Ein Modell aus einer anderen Familie sieht anders hin. Du brauchst dafür ein zweites Modell: eine zweite App (Codex, Claude Code oder Antigravity) oder einfach einen Browser-Chat. Dauer: ca. 25 Minuten.
>
> Start: `Lies quests/d_zwei-gehirne-duell.md und folge der Anleitung darin.`

---

# ANLEITUNG FÜR DIE KI

Lies zuerst die Regeln in `quests/00_QUESTS.md` (Abschnitt „REGELN FÜR JEDE QUEST") und halte dich daran. Projektname: `Duell`. Der Code kommt nach `system/PROJEKTE/Duell/code/`.

**Grenzen dieser Quest:** Das Programm ist klein (unter 80 Zeilen), läuft lokal, braucht kein Internet, keine Zugangsdaten, keine Zusatzpakete und schreibt nur in `system/PROJEKTE/Duell/`. Du startest es nicht selbst, das macht dein Mensch.

## Schritte

1. **Was bauen?** Schlag drei kleine Ideen aus seinem Profil vor (zum Beispiel ein Notenschnitt-Rechner, ein Passwort-Stärke-Check ohne Speichern, ein Lernplan-Generator) oder nimm seine eigene. Er wählt.
2. **Bauen (Modell A, das bist du).** Schreib das Programm nach `system/PROJEKTE/Duell/code/`, mit einer `LIESMICH.md`: wie man es startet, was es tut. Erklär in drei Sätzen, wie es funktioniert. Er startet es einmal selbst.
3. **Prüfen lassen (Modell B).** Gib ihm diesen Prüf-Prompt zum Kopieren:

   ```
   Du hast diesen Code nicht geschrieben. Du bist der Prüfer.
   Lies alle Dateien in system/PROJEKTE/Duell/code/. Ändere nichts.
   Finde die drei wichtigsten Probleme: Fehler, Sicherheitslücken, unklare Stellen.
   Zu jedem: Datei und Stelle, was passiert, wie du es lösen würdest. Je ein Satz.
   Lob nur mit Begründung.
   Schreib dein Ergebnis nach system/PROJEKTE/Duell/PRUEFUNG.md.
   ```

   Er öffnet das **andere** Modell in diesem Ordner und gibt ihm den Prompt. Läuft das zweite Modell nur im Browser, kopiert er Code und Prompt hinein und legt die Antwort selbst als `system/PROJEKTE/Duell/PRUEFUNG.md` ab.
4. **Duell auswerten.** Lies `PRUEFUNG.md`. Sag zu jedem Punkt ehrlich: stimmt, stimmt nicht, oder Geschmackssache, mit Grund. Gib dem Prüfer recht, wo er recht hat.
5. **Reparieren.** Er wählt höchstens zwei Punkte. Vor dem Ändern legst du die alte Fassung nach `system/ARCHIV/`. Dann reparierst du, er startet das Programm noch einmal.
6. **Ergebnis ablegen.** `JJJJ-MM-TT_Duell.md` im Projektordner: welche Modelle, welche Punkte, was repariert wurde.
7. **Abschluss** nach den Regeln in `quests/00_QUESTS.md`.
