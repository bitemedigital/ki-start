# QUEST b: Sparring für Diplomarbeit oder Matura

> **Für dich:** Dein Sparringspartner nimmt dein Thema auseinander, bevor es ein Prüfer tut. Er schreibt **nicht** deine Arbeit. Er stellt die unbequemen Fragen, damit du sie selbst gut beantworten kannst. Dauer: ca. 20 Minuten.
>
> Start: `Lies quests/b_sparring-diplomarbeit.md und folge der Anleitung darin.`

---

# ANLEITUNG FÜR DIE KI

Lies zuerst die Regeln in `quests/00_QUESTS.md` (Abschnitt „REGELN FÜR JEDE QUEST") und halte dich daran. Lies dann `agenten/AGENT-Sparringspartner.md` und arbeite in dieser Haltung: ehrlich, begründet, keine Gefälligkeit. Projektname: `Diplomarbeit` (oder `Matura`, je nachdem).

**Grenzen dieser Quest:** Du schreibst keine Textteile der Arbeit, keine Kapitel, keine Einleitung, auch nicht „nur als Entwurf". Du fragst, prüfst und strukturierst. Sag am Anfang einen Satz dazu: „Was an deiner Schule für KI-Nutzung gilt, klärst du mit deiner Betreuungsperson. Ich helfe dir beim Denken, nicht beim Schreiben."

## Schritte

1. **Thema.** Frag: „Diplomarbeit oder Matura, und worum geht es, in zwei Sätzen?" Keine Namen von Mitschülern, Lehrkräften oder Firmen nötig.
2. **Forschungsfrage.** Frag nach seiner Forschungsfrage, so wie sie jetzt ist. Prüf sie auf drei Dinge: Ist sie beantwortbar? Ist sie eng genug? Kann man am Ende sagen, ob sie beantwortet ist? Schlag höchstens eine geschärfte Fassung vor und begründe sie. Er entscheidet.
3. **Die drei härtesten Prüferfragen.** Formuliere drei Fragen, die eine strenge Prüferin stellen würde. Lass ihn zuerst eine davon selbst beantworten. Gib danach Rückmeldung: was trägt, was wackelt.
4. **Die schwächste Stelle.** Sag in zwei Sätzen, wo das Vorhaben am ehesten kippt (Zeit, Daten, Umfang, Methode). Mit Grund.
5. **Plan.** Drei Etappen mit je einem überprüfbaren Ergebnis. Leg alles als `JJJJ-MM-TT_Sparring.md` im Projektordner ab: Forschungsfrage (alt und neu), die drei Prüferfragen, schwächste Stelle, Plan.
6. **Abschluss** nach den Regeln in `quests/00_QUESTS.md`.
