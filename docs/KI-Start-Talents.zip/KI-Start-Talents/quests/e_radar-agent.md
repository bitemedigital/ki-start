# QUEST e: Radar-Agent

> **Für dich:** In KI ändert sich jede Woche etwas. Niemand kann alles lesen. Dein Radar-Agent macht daraus eine feste Routine: einmal pro Woche GitHub-Trending und drei Videos, und am Ende genau **ein** Hebel, den du in dieser Woche ausprobierst. Dauer: ca. 15 Minuten.
>
> Start: `Lies quests/e_radar-agent.md und folge der Anleitung darin.`

---

# ANLEITUNG FÜR DIE KI

Lies zuerst die Regeln in `quests/00_QUESTS.md` (Abschnitt „REGELN FÜR JEDE QUEST") und halte dich daran. Lies dann `radar/00_SO-GEHT-DEIN-RADAR.md` und `radar/WOCHE-VORLAGE.md`. Projektname: `Radar`.

**Grenzen dieser Quest:** Du erfindest keine Repos, Videos oder Inhalte. Was du nicht selbst gesehen hast, kommt von deinem Menschen: Links, Titel, seine Notizen. Fasst du etwas zusammen, das du nicht gelesen hast, sag das.

## Schritte

1. **Seine Themen.** Frag: „Welche zwei bis drei Themen willst du beobachten?" (zum Beispiel eine Programmiersprache, ein Framework, KI-Agenten, Security).
2. **Seine Quellen.** GitHub-Trending (github.com/trending, gefiltert nach seiner Sprache) und drei Videos pro Woche. Frag, welche Kanäle oder Suchbegriffe er nimmt, und welcher Wochentag fix sein soll.
3. **Den Agenten anlegen.** Schreib `agenten/AGENT-Radar.md` mit genau diesem Gerüst und seinen Angaben:

   ```
   # AGENT: Radar
   > Start: Lies agenten/AGENT-Radar.md und folge der Anleitung darin.
   ## Meine Themen
   ## Meine Quellen und mein Wochentag
   ## Ablauf (für die KI)
   1. Lies radar/WOCHE-VORLAGE.md und die letzte Radar-Datei in radar/.
   2. Frag nach dem GitHub-Fund der Woche und den drei Videos: Link und ein Satz, was drin war.
   3. Erfinde nichts. Was du nicht gesehen hast, kommt von deinem Menschen.
   4. Schreib radar/JJJJ-MM-TT_Radar.md nach der Vorlage.
   5. Schlag genau EINEN Hebel für diese Woche vor: klein, in unter einer Stunde ausprobierbar, passend zu seinem Profil.
   6. Frag am Ende, ob der Hebel der letzten Woche funktioniert hat, und schreib die Antwort dazu.
   ```

   Danach eine Zeile in `agenten/00_MEIN-TEAM.md` mit Startsatz.
4. **Erste Radar-Woche, jetzt gleich.** Er öffnet GitHub-Trending und sucht drei Videos zu seinen Themen. Er bringt Link und je einen Satz. Du schreibst `radar/JJJJ-MM-TT_Radar.md` nach der Vorlage.
5. **Ein Hebel.** Schlag genau einen Hebel vor. Er sagt, ob er ihn diese Woche macht. Trag die Antwort in die Radar-Datei ein.
6. **Abschluss** nach den Regeln in `quests/00_QUESTS.md`. Als nächsten Schritt in der Übergabe: der fixe Wochentag mit Startsatz.
