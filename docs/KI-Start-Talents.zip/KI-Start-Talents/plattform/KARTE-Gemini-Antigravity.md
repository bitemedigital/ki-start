# Karte: Gemini in Google Antigravity (gratis mit Google-Konto)

> Stand 01.11.2026. Gemini CLI für private Konten ist seit Juni 2026 durch **Google Antigravity** ersetzt. Antigravity gibt es als Desktop-App und als Terminal-Befehl `agy`.

## Warum dieser Weg

- **Gratis** mit einem normalen Google-Konto. Google gibt dir ein Kontingent, das sich **jede Woche erneuert**. Eine feste Zahl nennt Google nicht; ist es aufgebraucht, wartest du bis zur nächsten Woche oder arbeitest mit `GRATIS-FASSUNG.md` weiter.
- **Auch unter 18:** Google erlaubt Gemini Jugendlichen mit eigenem Google-Konto. Ob Antigravity für dein Konto freigeschaltet ist, siehst du beim ersten Anmelden.
- Antigravity liest `AGENTS.md` in diesem Ordner **von selbst**. Dein Coach, dein Gedächtnis und dein Team funktionieren also wie in Codex. (Von uns gemessen am 01.11.2026.)

## Weg A: Desktop-App (ohne Terminal)

1. Antigravity bei Google herunterladen und installieren (Suche: „Google Antigravity download"). Mit deinem Google-Konto anmelden.
2. In der App diesen Ordner `KI-Start-Talents` als Projekt bzw. Workspace öffnen. (Beim ersten Lauf prüfen: wie der Menüpunkt genau heißt.)
3. Neuen Chat starten und schreiben: `Lies 00_HIER-STARTEN.md und folge der Anleitung.`
4. Fragt die App, ob die KI Dateien schreiben darf: **ja, für diesen Ordner.** Dein Coach muss deine Notizen speichern können.

## Weg B: Terminal (getestet)

1. Antigravity installieren und `agy` einrichten (`agy install`), einmal anmelden.
2. Terminal **in diesem Ordner** öffnen und `agy` eingeben.
3. Schreiben: `Lies 00_HIER-STARTEN.md und folge der Anleitung.`
4. Schreibrechte für diesen Ordner erlauben, wenn gefragt.

**Prüfsatz:** `Welche Dateien liegen hier?` Kommen `START-COACH.md` und `KONFIG.md` zurück, bist du richtig.

## Gut zu wissen

- Datenschutz: Was die KI liest, verarbeitet Google. Bei Gratis-Konten in den Einstellungen nachsehen, ob deine Chats zum Training genutzt werden. Nichts hineinschreiben, was du nicht auch einem Fremden erzählen würdest.
- Gemini eignet sich auch als **zweites Gehirn zum Prüfen**: Hast du in Codex gebaut, lass Gemini drüberschauen (siehe Agentenbauer).
- Getestet haben wir den Terminal-Weg am Mac. Windows und die Desktop-App sind noch nicht in jedem Klick durchprobiert.
