# Karte: Claude Code

## Bevor du startest: einmal einrichten

Das machst du genau einmal. Danach nie wieder.

**Was du brauchst:** ein Anthropic-Konto mit einem Zugang, der Claude Code einschließt (laut Anthropic ab 18), und **Node.js** auf deinem Rechner (die Grundlage, auf der das Programm läuft).

**Auf Windows zusätzlich:** Claude Code braucht dort laut Anthropic Git for Windows (mit Git Bash) oder WSL. Halte dich für Windows an die aktuelle offizielle Anleitung von Anthropic zu Claude Code; unsere Schritte unten sind auf dem Mac getestet. Ohne Mac ist Codex der einfachere Weg.

**1. Node.js installieren,** falls noch nicht da: auf `nodejs.org` die empfohlene Version laden und den Installer durchklicken. Nichts umstellen, die Voreinstellungen passen.

**2. Das Programm installieren.** Terminal öffnen und eintippen (**wie du das Terminal öffnest, steht im nächsten Abschnitt weiter unten; spring einmal dorthin, mach das, komm dann hierher zurück**):

```
npm install -g @anthropic-ai/claude-code
```

Das rattert eine Weile. Solange Zeilen durchlaufen, ist alles in Ordnung.

**3. Prüfen, ob es geklappt hat:**

```
claude --version
```

Kommt eine Versionsnummer zurück, bist du fertig. Kommt `command not found` oder `konnte nicht gefunden werden`, hat Schritt 2 nicht funktioniert: Terminal einmal ganz schließen, neu öffnen, nochmal prüfen. Hilft das nicht, ist meist Node.js nicht sauber installiert.

**4. Beim allerersten Start** wirst du nach deinem Konto gefragt und einmal durch die Anmeldung geführt. Das passiert im Browser.

*Installationsbefehle ändern sich gelegentlich. Funktioniert der oben nicht, such die offizielle Anleitung von Anthropic zu Claude Code. Die ist immer aktueller als jede Datei in diesem Ordner.*

---

## Claude Code in diesem Ordner öffnen

Claude Code arbeitet immer in **dem Ordner, in dem du es startest**. Startest du es woanders, findet es deine Dateien nicht.

**Mac:** Finder → Rechtsklick auf diesen Ordner → *Dienste* → *Neues Terminal im Ordner*. *(Fehlt der Eintrag: Systemeinstellungen → Tastatur → Tastaturkurzbefehle → Dienste → „Neues Terminal im Ordner“ aktivieren.)* Alternative, die immer geht: Terminal öffnen, `cd ` tippen (mit Leerzeichen), den Ordner aus dem Finder ins Fenster ziehen, Enter.

**Windows:** Explorer → in die Adressleiste klicken → `cmd` eintippen → Enter. Oder Shift + Rechtsklick → „Im Terminal öffnen".

Dann `claude` eingeben, Enter.



Es öffnet sich ein Fenster mit einfarbigem Hintergrund und blinkendem Strich. Das ist das Terminal, und so soll es aussehen. Und die eine Sache, die niemand dazusagt: **ab jetzt tippst du dort ganz normale deutsche Sätze hinein, so wie in einen Chat.** Keine Befehle mehr.

**Woran du merkst, dass es stimmt:** Schreib `Welche Dateien liegen hier?` Wenn `START-COACH.md` und `KONFIG.md` erscheinen, bist du richtig.


## Dateien einfach hineinziehen

Du musst Dateinamen nie abtippen. Zieh eine Datei aus dem Explorer beziehungsweise Finder **direkt ins Fenster**, der Pfad steht dann von selbst da, und du schreibst nur noch dahinter, was damit passieren soll. Das ist der bequemste Weg, den Coach oder einen Agenten zu starten, und er funktioniert auf Windows und Mac gleich.

## Ein zweites Fenster

Für den Sparringspartner und den Auferstehungs-Test in Akt 4: zweites Terminal-Fenster, **derselbe Ordner**, dieselben Schritte. Das erste bleibt offen.

## Dauer-Anweisungen

Claude Code liest beim Start automatisch die Datei `CLAUDE.md` aus dem Ordner, in dem es läuft. Sie hat hier denselben Inhalt wie `AGENTS.md`, damit dein System in beiden Werkzeugen gleich funktioniert. **Änderst du eine von beiden, ändere die andere mit.**

## Ein Hinweis zum Aufräumen

Es gibt in solchen Werkzeugen Befehle, die den Gesprächsverlauf leeren. **Du brauchst sie in diesem Onboarding nie**, auch nicht am Schluss. Wenn du Platz brauchst, ist der richtige Weg immer: „Übergabe" sagen, dann ein frisches Fenster öffnen. Dann liegt dein Stand in einer Datei und nicht nur im Verlauf.

## Wenn etwas nicht geht

| Symptom | Meist die Ursache |
|---|---|
| `command not found` oder „konnte nicht gefunden werden“ | Das Programm ist noch nicht installiert. Ganz oben, Abschnitt „Bevor du startest“. Das ist kein Fehler von dir. |
| „Ich sehe keine Dateien" | Falscher Ordner. Nochmal von vorn. |
| Antworten werden schwammig | Kontextfenster voll. „Übergabe", neues Fenster. |
| Kennt seinen Namen nicht mehr | `CLAUDE.md` wurde nicht gelesen, meist falscher Ordner. |
