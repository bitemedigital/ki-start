# Karte: ChatGPT-App, Codex-Modus (Windows)

> Für dich und für die KI. Stand 25.09.2026, geprüft gegen die offizielle Hilfe von OpenAI (Quellen liegen bei biteme.digital).
> Du brauchst **keine Kommandozeile**. Alles passiert in der ChatGPT-App mit der Maus.
> Die Namen der Knöpfe stehen hier so, wie OpenAI sie auf Englisch dokumentiert. Ist deine App auf Deutsch, heißen sie sinngemäß übersetzt. Steht irgendwo **(beim ersten Lauf prüfen)**, war das zum Stand dieser Karte nicht offiziell belegt.

## Bevor du startest: einmal einrichten

Das machst du genau einmal.

**Was du brauchst:**
- Ein ChatGPT-Konto. Codex ist laut OpenAI in allen ChatGPT-Plänen enthalten, auch im kostenlosen. Wie viel du damit arbeiten kannst, hängt vom Plan ab.
- Einen Windows-Rechner. *(Welche Windows-Version mindestens nötig ist, nennt OpenAI nicht: beim ersten Lauf prüfen. Mit aktuellem Windows 11 bist du auf der sicheren Seite.)*

**1. Die App holen.** Im Browser `chatgpt.com/download` öffnen und die Fassung für Windows wählen. Sie kommt über den **Microsoft Store** („ChatGPT"). Dort auf Installieren klicken. **Nimm den Weg über `chatgpt.com/download`, nicht die Suche im Store:** dort gibt es mehr als einen Eintrag mit ChatGPT im Namen.
- *Hast du schon eine ältere ChatGPT-App?* Die heißt jetzt „ChatGPT Classic". Die neue App kommt dazu, beide dürfen nebeneinander liegen. Für dieses System brauchst du die **neue**.
- *Hast du schon die Codex-App?* Einfach wie gewohnt aktualisieren. Danach ist sie die neue ChatGPT-App.
- *Git, WSL, PowerShell-Einstellungen:* Die Hilfe von OpenAI erwähnt das für Entwickler. **Für dieses System brauchst du nichts davon.** Die App arbeitet von selbst im Windows-eigenen Modus.

**2. Öffnen und anmelden** mit deinem ChatGPT-Konto.

**3. Prüfen, ob Codex da ist.** Oben links ist ein Menü, in dem du zwischen **ChatGPT** und **Codex** wählst. Wähl **Codex**. Siehst du den Eintrag, bist du fertig mit Schritt 0.

---

## Deinen Ordner öffnen

Codex arbeitet immer in **dem Ordner, den du ihm gibst**. Gibst du ihm einen anderen, findet es deine Dateien nicht.

1. **Leg den Paket-Ordner an einen festen Platz**, den du wiederfindest, zum Beispiel in *Dokumente*. *(Ob ein Ordner, der über OneDrive synchronisiert wird, Probleme macht: beim ersten Lauf prüfen.)*
2. In der App oben links **Codex** wählen.
3. **Ordner öffnen:** Tastenkürzel **Strg + O** (heißt in der Hilfe *Open folder*). Alternativ auf der Startseite: *Start a chat, create a project, or open a folder*, dort den Ordner wählen.
4. Den Paket-Ordner im Explorer-Fenster auswählen, bestätigen. Er erscheint jetzt als **Projekt** in der Seitenleiste links.
5. **Git brauchst du nicht.** Ohne Git fehlen laut OpenAI nur Entwickler-Funktionen, etwa die Ansicht für Code-Änderungen. *(Dass ohne Git alles rund läuft: beim ersten Lauf prüfen.)*

**Woran du merkst, dass es stimmt:** Starte einen neuen Chat in diesem Projekt (**Strg + N**, *New chat*) und schreib: `Welche Dateien liegen hier?` Stehen `START-COACH.md` und `KONFIG.md` in der Antwort, bist du richtig.

## Wer darf was: die Freigaben

Unter dem Eingabefeld sitzt ein Schalter für die Berechtigungen. Der Standard heißt **Ask for approval**. Damit darf Codex in deinem Ordner lesen und schreiben und **fragt nach, bevor es darüber hinausgeht**. Das ist genau richtig für dieses System. Lass es dabei.

- Die Stufen *Approve for me* und *Full access* musst du erst in den Einstellungen freischalten. **Brauchst du hier nicht.**
- Die App **nicht als Administrator** starten. Das braucht man nur für Entwickler-Sonderfälle.
- Taucht eine Frage auf: lies, was Codex will. Geht es um Dateien in deinem Paket-Ordner, erlauben. Geht es um etwas außerhalb, lieber ablehnen und nachfragen. *(Wie die Frage genau aussieht und wie die Knöpfe heißen: beim ersten Lauf prüfen.)*

## Loslegen

Neuer Chat im Projekt (**Strg + N**), dann schreiben:

`Lies START-COACH.md und folge der Anleitung darin.`

Dateinamen musst du nicht abtippen, wenn du nicht willst. Dateien kann man einem Chat direkt anhängen. *(Ob Hineinziehen aus dem Explorer ins Eingabefeld geht: beim ersten Lauf prüfen. Abtippen geht immer.)*

## Zweites Fenster im selben Ordner

Für den Sparringspartner (Akt 3) und den Auferstehungs-Test (Akt 4) brauchst du ein **zweites Gespräch**, während das erste weiterläuft. In dieser App ist das ein **neuer Chat im selben Projekt**. Er startet mit leerem Schreibtisch, liest aber dieselben Dateien.

1. In der Seitenleiste auf dein Projekt klicken, dann **New chat** (oder **Strg + N**). *(Dass Strg + N dabei im gerade gewählten Projekt landet: beim ersten Lauf prüfen. Im Zweifel über die Seitenleiste gehen.)*
2. Gegencheck im neuen Chat: `Welche Dateien liegen hier?` Erscheinen `START-COACH.md` und `KONFIG.md`, ist es der richtige Ordner.
3. Das erste Gespräch bleibt in der Seitenleiste stehen. Ein Klick darauf, und du bist zurück. Nichts schließen, nichts löschen.
4. **Nebeneinander sehen, wenn du willst:** Die App kann einen laufenden Chat in ein **eigenes Fenster** herauslösen. *(Wo der Knopf dafür sitzt und wie er heißt: beim ersten Lauf prüfen. Für den Test ist es nicht nötig.)*

**Zwei Fallen:**
- **Nicht *Quick chat* nehmen** (auch nicht über **Strg + Alt + N**). Das ist ein ganz normaler ChatGPT-Chat **ohne** deinen Ordner. Dort findet der Test nichts.
- **Nicht oben links auf *ChatGPT* wechseln.** Der Test läuft in **Codex**.

*Für die KI:* Das Gedächtnis-Feature der App (*Memories*) ist für Codex laut OpenAI standardmäßig **aus** (Einstellungen, *Personalization*). Ist es eingeschaltet, kann eine neue Sitzung Dinge wissen, die nicht aus den Dateien stammen. Dann ist der Auferstehungs-Test weniger aussagekräftig. Sag das in einem Satz, wenn du es bemerkst.

## Dauer-Anweisungen

Codex liest die Datei `AGENTS.md` aus dem **Hauptordner des Projekts** automatisch, bei jedem neuen Chat. Was dort steht, gilt, ohne dass du es erwähnst. Deshalb liegt sie hier.

- Hat dein Projekt nur einen Ordner, ist er automatisch der Hauptordner.
- Hängst du später weitere Ordner an, bleibt der Paket-Ordner Hauptordner. Umstellen würde man über das Projekt-Menü, *Edit project*, *Make primary*. **Nicht nötig, solange alles läuft.**

**Gegenprobe beim ersten Lauf:** In einem neuen Chat fragen: `Fasse in drei Sätzen zusammen, welche Dauer-Anweisungen du für diesen Ordner hast.` Kommt etwas aus `AGENTS.md` zurück, wirkt sie.

## Ein Hinweis zum Aufräumen

**Du löschst in diesem Onboarding nie einen Chat.** Wenn ein Gespräch zu voll wird: „Übergabe" sagen, dann neuer Chat im selben Projekt. Fertige Chats kann man **archivieren**, sie sind dann aus dem Weg und über die Einstellungen (*Archived chats*) wieder da.

## Wenn es hakt

| Symptom | Meist die Ursache | Was du tust |
|---|---|---|
| Oben links gibt es kein **Codex** | Du hast die alte App („ChatGPT Classic") offen, oder dein Firmenkonto hat Codex gesperrt | Neue App über `chatgpt.com/download` beziehungsweise den Microsoft Store holen. Bei Firmenkonto: Administrator fragen |
| Installation im Microsoft Store klappt nicht | Store-Problem auf dem Rechner, kommt vor | Rechner neu starten, Store aktualisieren, nochmal. Hilft das nicht: den Terminal-Weg nehmen (`plattform/KARTE-Codex.md`) |
| „Ich sehe keine Dateien" | Chat ist nicht im Projekt, oder es ist ein *Quick chat* | Links auf das Projekt klicken, dort **New chat** |
| Im Paket-Ordner tauchen plötzlich Ordner wie `.git`, `.codex` oder `.agents` auf | Die App legt manchmal eigene Hilfsordner an (von Nutzern gemeldet, nicht offiziell bestätigt) | Nicht löschen, nicht umbenennen, einfach weiterarbeiten |
| Der Assistent kennt seinen Namen nicht mehr | `AGENTS.md` wurde nicht gelesen: falscher Ordner, oder er ist nicht der Hauptordner | Gegencheck `Welche Dateien liegen hier?`. Stimmt der Ordner, Gegenprobe aus „Dauer-Anweisungen" machen |
| Das zweite Gespräch weiß nichts | Falsches Projekt, *Quick chat*, oder oben links steht *ChatGPT* statt *Codex* | Zurück in **Codex**, Projekt wählen, **New chat** |
| Das zweite Gespräch übernimmt den Coach statt den Stand zu sagen | Die Boot-Logik greift | Schreib: `Antworte nur mit dem Stand, starte kein Onboarding.` |
| Antworten werden schwammig, wiederholen sich | Das Gespräch ist voll | „Übergabe" sagen, dann neuer Chat im selben Projekt |
| Meldung, dass etwas „blockiert" oder „nicht ausgeführt" wurde | Windows-Sicherheitseinstellung für Skripte | Nichts selbst umstellen. Den Terminal-Weg nehmen (`plattform/KARTE-Codex.md`) |

*Klickwege ändern sich bei solchen Apps öfter als alles andere. Stimmt hier etwas nicht mehr, gilt die aktuelle Hilfe von OpenAI. Frag nicht die KI nach der Wahrheit über sich selbst.*
