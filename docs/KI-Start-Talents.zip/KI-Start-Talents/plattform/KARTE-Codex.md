# Karte: ChatGPT Codex

## Bevor du startest: einmal einrichten

Das machst du genau einmal. Danach nie wieder.

**Was du brauchst:** ein OpenAI-Konto mit einem Zugang, der Codex einschließt, und **Node.js** auf deinem Rechner (die Grundlage, auf der das Programm läuft).

**1. Node.js installieren,** falls noch nicht da: auf `nodejs.org` die empfohlene Version laden und den Installer durchklicken. Nichts umstellen, die Voreinstellungen passen.

**2. Das Programm installieren.** Terminal öffnen und eintippen (**wie du das Terminal öffnest, steht im nächsten Abschnitt weiter unten; spring einmal dorthin, mach das, komm dann hierher zurück**):

```
npm install -g @openai/codex
```

Das rattert eine Weile. Solange Zeilen durchlaufen, ist alles in Ordnung.

**3. Prüfen, ob es geklappt hat:**

```
codex --version
```

Kommt eine Versionsnummer zurück, bist du fertig. Kommt `command not found` oder `konnte nicht gefunden werden`, hat Schritt 2 nicht funktioniert: Terminal einmal ganz schließen, neu öffnen, nochmal prüfen. Hilft das nicht, ist meist Node.js nicht sauber installiert.

**4. Beim allerersten Start** wirst du nach deinem Konto gefragt und einmal durch die Anmeldung geführt. Das passiert im Browser.

*Installationsbefehle ändern sich gelegentlich. Funktioniert der oben nicht, such die offizielle Anleitung von OpenAI zu Codex. Die ist immer aktueller als jede Datei in diesem Ordner.*

---

## Codex in diesem Ordner öffnen

Das ist der einzige Schritt, an dem es hakt, wenn es hakt. Codex arbeitet immer in **dem Ordner, in dem du es startest**. Startest du es woanders, findet es deine Dateien nicht.

**Mac:**
1. Finder öffnen, zu diesem Ordner (`KI-Start-Talents`) navigieren.
2. Rechtsklick auf den Ordner → **Dienste** → *Neues Terminal im Ordner* (oder *Neuer Terminal-Tab im Ordner*).
   *Fehlt der Eintrag: Systemeinstellungen → Tastatur → Tastaturkurzbefehle → Dienste → „Neues Terminal im Ordner" aktivieren.*
3. **Alternative, die immer geht:** Terminal öffnen (Spotlight mit `cmd`+Leertaste, „Terminal" tippen), dann `cd ` schreiben (mit Leerzeichen am Ende) und den Ordner aus dem Finder ins Terminal-Fenster **ziehen**. Enter.
4. `codex` eingeben, Enter.

**Windows:**
1. Explorer öffnen, zu diesem Ordner navigieren.
2. In die Adressleiste oben klicken, `cmd` eintippen, Enter. Das öffnet die Eingabeaufforderung in genau diesem Ordner.
   *Oder: Shift + Rechtsklick in den Ordner → „PowerShell-Fenster hier öffnen" / „Im Terminal öffnen".*
3. `codex` eingeben, Enter.



Es öffnet sich ein Fenster mit einfarbigem Hintergrund und blinkendem Strich. Das ist das Terminal, und so soll es aussehen. Und die eine Sache, die niemand dazusagt: **ab jetzt tippst du dort ganz normale deutsche Sätze hinein, so wie in einen Chat.** Keine Befehle mehr.

**Woran du merkst, dass es stimmt:** Schreib als Erstes `Welche Dateien liegen hier?` Wenn `START-COACH.md` und `KONFIG.md` in der Antwort stehen, bist du richtig.


## Dateien einfach hineinziehen

Du musst Dateinamen nie abtippen. Zieh eine Datei aus dem Explorer beziehungsweise Finder **direkt ins Fenster**, der Pfad steht dann von selbst da, und du schreibst nur noch dahinter, was damit passieren soll. Das ist der bequemste Weg, den Coach oder einen Agenten zu starten, und er funktioniert auf Windows und Mac gleich.

## Ein zweites Fenster

Für den Sparringspartner und für den Auferstehungs-Test in Akt 4 brauchst du ein **zweites** Fenster, während das erste offen bleibt. Öffne dazu einfach ein zweites Terminal-Fenster und mach genau dieselben Schritte wie oben. **Es muss derselbe Ordner sein**, sonst findet die zweite Sitzung deine Dateien nicht und der Test schlägt fehl, obwohl mit deinem System alles in Ordnung ist.

## Dauer-Anweisungen

Codex liest beim Start automatisch die Datei `AGENTS.md` aus dem Ordner, in dem es läuft. Was dort steht, gilt in jeder Sitzung, ohne dass du es erwähnst. Deshalb liegt sie hier.

*(Wenn du bei Befehlsnamen oder Optionen unsicher bist, frag nicht die KI nach der Wahrheit über sich selbst; schau in die aktuelle Dokumentation oder ruf die eingebaute Hilfe auf. Solche Details ändern sich häufiger als alles andere.)*


## Ein Hinweis zum Aufräumen

Es gibt in solchen Werkzeugen Befehle, die den Gesprächsverlauf leeren. **Du brauchst sie in diesem Onboarding nie**, auch nicht am Schluss. Wenn du Platz brauchst, ist der richtige Weg immer: „Übergabe“ sagen, dann ein frisches Fenster öffnen. Dann liegt dein Stand in einer Datei und nicht nur im Verlauf.

## Wenn etwas nicht geht

| Symptom | Meist die Ursache |
|---|---|
| `command not found` oder „konnte nicht gefunden werden“ | Das Programm ist noch nicht installiert. Ganz oben, Abschnitt „Bevor du startest“. Das ist kein Fehler von dir. |
| „Ich sehe keine Dateien" | Falscher Ordner. Terminal schließen, oben nochmal. |
| Antworten werden schwammig, wiederholen sich | Kontextfenster voll. Sag „Übergabe", dann neues Fenster. |
| Der Assistent kennt seinen Namen nicht mehr | `AGENTS.md` wurde nicht gelesen, meist wieder der falsche Ordner. |
