# Mein Team

Jedes Teammitglied ist eine Datei. Du aktivierst es, indem du ein Fenster in diesem Ordner öffnest und schreibst: `Lies agenten/<Datei> und folge der Anleitung darin.`

| Wer | Wofür | Datei |
|---|---|---|
| **Coach** (Onboarder) | Richtet dein System mit dir ein. Startet als Erstes. | `../START-COACH.md` |
| **Sparringspartner** | Ideen, Pläne und Entscheidungen ehrlich prüfen lassen. Kennt dich aus deinem Profil. | `AGENT-Sparringspartner.md` |
| **Agentenbauer** | Weitere Spezialisten selbst bauen, mit Gegenprüfung im anderen Modell. | `AGENT-Agentenbauer.md` |

**Faustregel:** Ein eigenes Fenster pro Rolle. Dein Assistent im Hauptfenster hält den roten Faden, die Spezialisten machen ihre Sache und geben das Ergebnis zurück.

Neue Teammitglieder trägst du hier ein, sobald du sie gebaut hast. Ein fertiges Beispiel aus fünf Dateien liegt in `beispiel/Code-Pruefer/`, Bau-Aufträge in `quests/00_QUESTS.md`.

**Radar:** Einmal pro Woche `radar/00_SO-GEHT-DEIN-RADAR.md`. Die Radar-Runde macht der Sparringspartner.
