# PROJEKTE

Ein Unterordner pro Thema oder Projekt. Darin immer dieselben zwei Dateien:

- `EINSTIEG.md`: worum geht es, wer ist beteiligt, was ist das Ziel. Ändert sich selten.
- `STAND.md`: wo stehst du, was ist entschieden, was kommt als Nächstes. Ändert sich ständig, neueste Übergabe steht oben.

Der Ordner `_VORLAGE/` ist kein Projekt, sondern das Kopiergerüst dafür.

Mehr braucht es am Anfang nicht. Dein Assistent legt neue Projekte für dich an, wenn du sagst: „Leg ein neues Projekt für … an."
