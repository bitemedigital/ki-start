# STAND: [Projektname]

> Neueste Übergabe steht oben. Ältere bleiben stehen, nichts wird gelöscht.

## [JJJJ-MM-TT]

**Was gemacht:**
**Was entschieden:**
**Nächster Schritt:**
**Betroffene Dateien:**
**Offene Risiken:**
