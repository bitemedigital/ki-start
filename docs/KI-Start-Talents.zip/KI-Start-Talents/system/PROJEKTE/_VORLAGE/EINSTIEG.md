# EINSTIEG: [Projektname]

> Vorlage. Dein Assistent kopiert diesen Ordner, wenn du sagst: „Leg ein neues Projekt für … an."

**Worum geht es?**
Ein bis drei Sätze. Was ist das Ziel, woran merkt man, dass es erreicht ist.

**Wer ist beteiligt?**
Rollen, auch deine eigene. Keine echten Namen anderer Menschen: Kürzel oder erfundene Namen reichen.

**Rahmen**
Termine, Abgaben, harte Vorgaben.

**Was du wissen musst, bevor du hier mitarbeitest**
Die zwei, drei Dinge, die man sonst falsch macht.
