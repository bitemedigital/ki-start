# STAND: der eine Ort, an dem steht, wo du gerade bist

> Diese Datei liest jede frische KI-Sitzung als Erstes. Sie ist kurz und immer aktuell.

## ONBOARDING: noch nicht gelaufen

*(Der Coach ändert diese Zeile. Mögliche Werte: `noch nicht gelaufen` · `aktiv` · `abgeschlossen`.)*

**Wiedereinstieg:** noch keiner
**Projektpfad des Onboarding-Projekts:** noch keiner

---

## Aktueller Stand

Noch nichts. Nach dem Onboarding steht hier, woran du zuletzt gearbeitet hast und was als Nächstes dran ist.

## Meine Projekte

*(Der Assistent trägt hier jedes neue Projekt mit Pfad ein.)*
