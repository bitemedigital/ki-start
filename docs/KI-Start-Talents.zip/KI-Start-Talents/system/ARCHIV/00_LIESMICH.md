# ARCHIV

Hier liegen überholte Fassungen. **Es wird nichts gelöscht, es wird verschoben.**

Ehrlich zur Einordnung: dieses Archiv ist kein Sicherheitsnetz, das von allein spannt. Es schützt dich nur, wenn eine alte Fassung tatsächlich hierher verschoben wurde, **bevor** die neue geschrieben wurde. Wenn du oder dein Assistent eine Datei direkt überschreibt, ist die alte Fassung weg.

Die Regel, die wirklich hilft: bevor etwas Wichtiges überschrieben wird, sag „Leg die alte Fassung ins Archiv." Dateiname mit Datum davor, dann findest du sie wieder.
