# RÜCKMELDUNG: wie es dir nach ein paar Wochen geht

> Diese Datei ist für dich. Nach ein paar Wochen lohnt ein ehrlicher Blick: Was nutzt du wirklich? Wenn du magst, schick deine Antworten an Jürgen: juergen@biteme.digital. Freiwillig, kein Termin, keine Note für das System.

**Onboarding abgeschlossen am:** ______
**Mein Projektordner:** ______

## Die drei Fragen

**1. Was nutzt du diese Woche wirklich?**


**2. Wo hat es gehakt?**


**3. Was fehlt dir?**


---

*Du kannst die Antworten selbst eintragen oder deinem Assistenten sagen: „Geh mit mir die Rückmeldung durch." Er trägt sie dann hier ein. Verschickt wird nichts automatisch.*
