# So funktioniert dein Gedächtnis

Eine KI vergisst am Ende eines Chats fast alles. Manche Apps haben zwar eine eigene Merkfunktion (Memory), aber die siehst und steuerst du kaum. Dein verlässliches Gedächtnis liegt deshalb nicht in der KI, sondern **hier, in Dateien auf deiner Festplatte**. Die KI liest sie beim Start und schreibt sie fort.

## Die fünf Teile

**`PROFIL.md`: wer du bist.** Wächst über das Onboarding hinweg und danach weiter. Jeder Agent liest sie zuerst. Das ist der Grund, warum dein Sparringspartner dich kennt.

**`STAND.md` (hier im Ordner): wo du gerade bist.** Eine kurze Datei, die immer sagt: woran hast du zuletzt gearbeitet, was ist der nächste Schritt. Die liest jede frische Sitzung.

**`PROJEKTE/`: deine Themen.** Ein Unterordner pro Projekt, darin `EINSTIEG.md` (worum geht es) und eine eigene `STAND.md` (wie weit bist du, mit den Übergaben, neueste zuerst).

**`LEARNINGS.md`: was nie wieder passieren soll.** Jeder Fehler, aus dem ihr etwas gelernt habt, wird eine Regel in einem Satz, mit Datum. Jede Sitzung liest diese Datei zuerst. So wird dein System mit jedem Fehler besser, statt ihn zu wiederholen.

**`ARCHIV/`: was überholt ist.** Nichts wird gelöscht. Alte Fassungen wandern hierher. Achtung, ehrlich gesagt: das passiert nicht automatisch. Du oder dein Assistent müsst es aktiv tun, bevor etwas überschrieben wird.

## Die eine Bewegung, die alles trägt: die Übergabe

Wenn ein Chat zu Ende geht oder zu voll wird, sagst du: **„Übergabe."** Dein Assistent schreibt dann fünf Punkte in die `STAND.md`:

1. Was haben wir gemacht?
2. Was haben wir entschieden?
3. Was ist der nächste Schritt?
4. Welche Dateien sind betroffen?
5. Welche Risiken sind noch offen?

Im nächsten Chat liest er das und macht weiter, als wäre nie unterbrochen worden. Das ist die wichtigste Technik in diesem ganzen System, und sie kostet dich ein Wort. Danach fragt dein Assistent noch: Ist etwas schiefgegangen, das nie wieder passieren soll? Das wird ein Learning.
