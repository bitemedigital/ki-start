# LEARNINGS: was nie wieder passieren soll

> Jede Sitzung liest diese Datei zu Beginn. Ein Fehler, den du aufschreibst, passiert dir nie wieder. Einer, den du nicht aufschreibst, jede Woche.

**Format, eine Zeile pro Regel:** `- JJJJ-MM-TT · Die Regel in einem Satz · was passiert ist, ganz kurz`

**Beispiel:** `- 2026-11-04 · Neue Dateien immer im Projektordner anlegen, nie im Hauptordner · die Gliederung lag einen Tag lang am falschen Ort`

## Meine Regeln

*(Noch keine. Die erste entsteht meistens bei der ersten Übergabe.)*
