# PROFIL: was dein System über dich weiß

> **Das ist das Herzstück.** Diese Datei wächst über das ganze Onboarding hinweg mit: nach jedem Akt trägt der Coach hier ein, was er über dich gelernt hat. Danach liest dein Sparringspartner sie bei jedem Start, deshalb kennt er dich, ohne dass du dich jedes Mal neu erklären musst.
>
> Du darfst hier jederzeit selbst hineinschreiben, korrigieren oder streichen. Es ist deine Datei.

## Wer ich bin
*(Akt 1)*
- **Name:**
- **Was ich mache:**
- **Mein Umfeld:**

## Mein Assistent
*(Akt 1, bestätigt im Abschluss)*
- **Rufname:**
- **Warum dieser Name:**
- **Wie ich angesprochen werden will:**

## Persönlichkeit meines Assistenten
*(Akt 1, in meinen Worten; ich kann sie jederzeit ändern)*
- **Wie er mit mir redet:**
- **Was ihm bei meiner Arbeit wichtig ist:**
- **Was er nie tut:**

## Wie ich arbeite
*(Akt 1 und 2)*
- **Womit ich die meiste Zeit verbringe:**
- **Was mir regelmäßig verloren geht:**
- **Wie ich am liebsten Feedback bekomme:**
- **Was mich an KI bisher genervt hat:**

## Woran ich gerade arbeite
*(Akt 2, wird laufend fortgeschrieben)*
- **Aktuelle Themen:**
- **Anstehende Entscheidungen:**

## Wie mein Sparringspartner mit mir umgehen soll
*(Akt 3, hier wird es konkret)*
- **Wo ich mir selbst zu schnell recht gebe:**
- **Welche Art von Widerspruch bei mir ankommt:**
- **Welche Art von Widerspruch bei mir abprallt:**
- **Mein Fachgebiet, in dem er mitdenken können muss:**
- **Themen, bei denen er besonders hart sein soll:**

## Gelernt im Alltag
*(nach dem Onboarding: eine Zeile pro Erkenntnis, nur nach meinem Ja)*
- 

## Was ich kann
*(wächst weiter, auch nach dem Onboarding)*
- **Beherrsche ich:**
- **Wackelt noch:**

---

*Diese Datei ist nie fertig. Wenn sich etwas ändert, sag es deinem Assistenten: „Trag in mein Profil ein, dass …"*
